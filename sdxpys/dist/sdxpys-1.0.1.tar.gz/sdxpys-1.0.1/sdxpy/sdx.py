sdx = "尚德勋"

def speak():
    print("我是河南商丘民权的：",sdx)

speak()